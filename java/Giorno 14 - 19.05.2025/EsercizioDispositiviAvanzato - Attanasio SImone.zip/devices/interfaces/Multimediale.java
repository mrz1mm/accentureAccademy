package interfaces;

public interface Multimediale {

    void riproduciMedia();
    void fermaRiproduzione();

}
