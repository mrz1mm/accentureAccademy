package interfaces;

public interface Connettibile {

    void connettiAInternet();

    void disconnettiDaInternet();

}
